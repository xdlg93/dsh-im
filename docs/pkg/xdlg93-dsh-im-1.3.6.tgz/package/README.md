# dsh-im：把微信与 QQ 接入 DeepSeek Harness

在 DSH 设置页扫码绑定机器人，就能直接在微信或 QQ 里和本机运行的 DeepSeek Harness 对话：发消息、跑任务、审批、看结果，全部落在你平时聊天的那个窗口里。

> **关于本仓库**
>
> 本项目基于 [xmanrui/dsh-im](https://github.com/xmanrui/dsh-im) **5.10.0** 二次开发，遵循 MIT 许可，上游版权归 xmanrui 及贡献者所有。
>
> 本分支（[xdlg93/dsh-im](https://github.com/xdlg93/dsh-im)，作者 xdlg93）**只保留微信与 QQ 两个扫码通道**，其他通道的代码、界面与文档均已移除。上游署名与 MIT 许可全文见 [LICENSE](LICENSE)，第三方组件声明见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。

## 目录

- [支持矩阵](#支持矩阵)
- [兼容性](#兼容性)
- [安装](#安装)
- [快速开始：微信](#快速开始微信)
- [快速开始：QQ](#快速开始qq)
- [通用能力](#通用能力)
- [数据与隐私](#数据与隐私)
- [常见问题](#常见问题)
- [开发](#开发)
- [许可证与致谢](#许可证与致谢)

## 这个 fork 做了什么

上游 dsh-im 把十几个 IM 平台塞进同一个设置页，代码量和文档都随之膨胀。本分支做了一次彻底裁剪：

| 变化 | 说明 |
| --- | --- |
| 只保留两个通道 | 微信、QQ；其余通道的 Host、客户端、测试与文档全部删除，不再有隐藏入口或半成品代码。 |
| 只保留扫码接入 | 两个通道都以扫码为主路径，不再维护各家平台的手工凭据表单、App Manifest 和应用权限补全流程。 |
| 文档重写 | README、CHANGELOG、主动投递指南都按「微信 + QQ」重写，只描述真实存在的功能。 |
| 共享能力不变 | 会话同步、群记录、上下文增强、主动投递、模型与工作区设置等两个通道共用的能力全部保留。 |

如果你需要飞书、钉钉、企业微信、Telegram、Slack、Discord、WhatsApp、Matrix、iMessage 或邮箱接入，请使用[上游项目](https://github.com/xmanrui/dsh-im)。

## 支持矩阵

| 通道 | 接入方式 | 消息收发 |
| --- | --- | --- |
| **微信** | 手机微信扫码（腾讯 iLink） | iLink 长轮询收发消息；等待回答时显示「正在输入」，最终回复按 1,800 字符分段发送 |
| **QQ** | 手机 QQ 扫码授权 | 官方 WebSocket 长连接；私聊显示「正在输入」并以单条 Markdown 回复，群聊被 @ 后只发送最终答案 |

两个通道都支持：

- 同一个通道接入多个机器人，每个机器人的连接状态、工作区、模型和会话绑定彼此独立；
- 扫码、账号管理、私聊策略与 QQ 群聊策略、上下文增强、会话标题前缀、主动推送、模型设置、工作区绑定；
- 图片与文件双向收发、QQ 群聊记录、排队与插话、交互式提问与远程审批；
- 跟随 DSH 界面语言的中文、English、Русский 机器人消息。

## 兼容性

| 项目 | 要求 |
| --- | --- |
| DeepSeek Harness | **0.2.2-rc.5 及以上**（`package.json` 的 `dsh.compatibility.dsh`） |
| Node.js | 22.19 及以上 |
| 运行 profile | `web`（插件在 `dsh.compatibility.profiles` 中声明）；DSH Desktop 使用同一插件，安装命令见下文 |

插件只声明实际验证过的宿主版本，不承诺未经验证的未来版本。升级插件后请重启 Host 并刷新页面，让 Host 与客户端加载同一版插件。

## 安装

这个包**目前没有发布到 npm**，请从 Git 仓库安装（版本用 tag 固定），或从插件发现索引安装。

**从插件索引安装（推荐）**：设置 → 插件 → 发现 → 添加索引源，粘贴：

```
https://xdlg93.github.io/dsh-im/index.json
```

搜到「DSH IM 机器人（微信 + QQ）」后直接安装。索引在 Pages 生效前可以用同一个文档的 raw 地址：
`https://raw.githubusercontent.com/xdlg93/dsh-im/main/docs/index.json`。

**从 Git 安装**：在启动当前 Harness 的终端里执行，然后重启 `dsh web` 并刷新浏览器：

```sh
dsh plugin --profile web install git+https://github.com/xdlg93/dsh-im.git#v1.3.3
```

**DSH Desktop**：在 Desktop 的内置终端中执行，然后完全退出并重新打开 Desktop：

```sh
dsh plugin --profile desktop install git+https://github.com/xdlg93/dsh-im.git#v1.3.3
```

`dsh plugin` 的 `--profile` 必须写成当前实际运行的 profile 名；`install` 也可以写成 `add`。把 `#v1.3.3`
换成需要的 tag（或省略它取 `main`）即可升级或回退。

### 网络受限时（git 需要直连 github.com）

从插件索引或 Git 安装都会让 `pnpm` **直接 `git clone` github.com**，这一步**不经过 npm 源，也不吃 npm 的代理配置**。国内直连失败时会看到
`fatal: unable to access 'https://github.com/xdlg93/dsh-im.git/': Recv failure: Connection was reset`。

三种做法，任选其一：

**1）给 DSH 进程设置代理环境变量**（git 子进程会继承 `HTTPS_PROXY`）。以 systemd 为例：

```sh
sudo systemctl edit dsh-web
# 在打开的编辑器里加入：
#   [Service]
#   Environment=HTTPS_PROXY=http://127.0.0.1:7890
#   Environment=HTTP_PROXY=http://127.0.0.1:7890
sudo systemctl restart dsh-web
```

命令行启动时直接 `HTTPS_PROXY=http://127.0.0.1:7890 dsh web` 同样有效。

**2）让 git 自己走代理**（只影响 git）：

```sh
git config --global http.proxy http://127.0.0.1:7890
# 取消：git config --global --unset http.proxy
```

**3）用 tgz 直链安装**（不需要 git，也不需要 npm 账号，只访问 `xdlg93.github.io`）：

```sh
dsh plugin --profile web add https://xdlg93.github.io/dsh-im/pkg/dsh-im-1.3.3.tgz
```

每个版本都会在 `docs/pkg/` 留一份 `dsh-im-<版本>.tgz`，地址规则相同。tgz 安装后插件内的「检查更新」仍按插件索引工作；
需要更新时重复上面这条命令即可。

**在 DSH 界面里安装**：也可以让 Agent 通过插件管理工具用 `plugin_manager install_bundle` 安装同一个 Git 地址，或直接编辑 profile 的 `package.json` 依赖后重启。无论哪种方式，安装完成后都要重启 Host。

**本地开发 / link 安装**：克隆本仓库后把绝对路径装进 profile，修改代码后重新构建即可：

```sh
git clone https://github.com/xdlg93/dsh-im.git
cd dsh-im
npm install
npm run build
dsh plugin --profile web add "$(pwd)"
```

本地目录安装后，profile 依赖里会记录 `link:` 路径；重新构建后重启 Host 生效。

安装完成并重启后，打开 **设置 → IM机器人**，应该能看到左侧的 **微信** 与 **QQ** 两个标签页。插件在 DSH 一级设置菜单中注册「IM机器人」，支持侧边栏入口的 DSH 还会在左侧边栏显示同名入口。

## 快速开始：微信

微信通道使用腾讯 iLink 扫码登录，绑定后这个微信账号就作为机器人与 Harness 收发消息。

1. 打开 **设置 → IM机器人 → 微信**。
2. 点击 **扫码接入机器人**，等待二维码生成（二维码由腾讯微信 iLink 服务签发）。
3. 用手机微信扫描二维码。
4. 在手机上确认连接该机器人。
5. 如果页面提示「需要配对码」，回到设置页输入**手机微信上显示的数字**（微信附加的安全确认步骤；配对码只用于本次扫码轮询，不会写入配置或日志）。
6. 页面显示「微信已确认，正在启动消息连接」后稍等片刻，凭据会直接写入本机 Harness Host，浏览器始终拿不到 `bot_token`。
7. 在微信里给这个机器人发一条消息，就能开始使用。

注意事项：

- 二维码有有效期，过期后点 **重新生成二维码** 或 **换一个二维码** 即可；一个账号扫码失败不影响其他已绑定的账号。
- 每个微信账号在设置页是一张独立卡片，可以分别设置别名、工作区、模型、Agent Preset 和访问策略。
- 微信目前只有私聊：群聊区域会提示当前渠道不支持群聊，保存私聊设置时会保留已有群聊策略。
- 不再使用时在卡片上点 **移除接入**，插件会停止连接并删除本机保存的 `bot_token`、账号配置和会话映射，其他账号不受影响。

## 快速开始：QQ

QQ 通道使用 `@tencent-connect/qqbot-connector` 的扫码授权创建或绑定机器人，再用 `@tencent-connect/qqbot-nodejs` 建立 WebSocket 长连接收发消息。

1. 打开 **设置 → IM机器人 → QQ**。
2. 点击 **扫码接入机器人**，等待二维码生成。
3. 用手机 QQ 扫描二维码。
4. 在腾讯授权页面确认创建或绑定机器人；二维码会按需自动刷新，过期后也可点 **重新生成二维码**。
5. 授权成功后页面显示「QQ 已授权，正在连接机器人」，凭据写入本机并启动消息连接。
6. 配置完成后，在 QQ 里**@机器人**（私聊直接发消息）开始对话。

注意事项：

- QQ 群聊只在机器人被 @ 时响应，普通群消息不会触发回答；私聊直接响应。
- QQ 机器人发送文件受当日上传配额约束，额度耗尽时会明确提示稍后重试。
- 同一个通道可以接入多个 QQ 机器人，每张卡片独立保存工作区、模型与访问策略。

## 通用能力

两个通道共享同一套能力，配置入口都在 **设置 → IM机器人** 的对应标签页里。

### 会话与工作区

- 每张机器人卡片显示当前 Harness 工作区，可直接填写绝对路径或打开目录选择器切换。切换只清除该机器人的旧聊天映射，不删除、不清空旧 Session。
- 新机器人的默认工作区是**与 DSH 工作区同级**的 `dsh-im` 目录（例如 DSH 工作区是 `/home/me/DSH/workspace`，默认目录就是 `/home/me/DSH/dsh-im`），避免机器人的文件写进你自己的工作区；Host 没有注册任何工作区时（headless / CLI）回落到 `$DSH_HOME/im`（未设置 `DSH_HOME` 时为 `~/.dsh/im`）。该目录在真正被使用时才创建；新会话显示在「未分组」。
- 在聊天里发送 `/sessionlist`、`/session <ID 或序号>` 可以查看和绑定已有会话，`/new` 让下一条消息开一个全新会话。
- 可选按 Agent Preset 自动分组：在插件配置中设置 `groupByAgentPreset: true` 后，新会话会进入 `presets/<preset-id>` 工作区。详见 [配置说明](docs/preset-workspaces.md)。

### 群聊记录（QQ）

QQ 会自动保存实际收到的群消息与附件，包括平台允许接收的未 @ 消息；保存本身不会触发模型回复。在群里 @ 机器人即可查询记录、总结讨论或读取文件。

记录按群共享，独立于机器人和工作区，默认滚动保留 14 天，可在 **通用设置 → 通用 → 群聊天记录保留天数** 修改。只保存实际接收的内容，不回填完整历史。详见 [群消息记录与群文件使用指南](docs/group-history.md)。

### 上下文增强

每张机器人卡片都可以打开 **上下文增强**，分别配置群聊与私聊的开关、来源字段和增强提示词，保存后原子生效。可选字段包括 `channel`、`conversationType`、`senderId`、`senderName`、`conversationTitle`、`chatId`、`threadId`、`botId`，默认只启用 `senderId`。插件只发送当前场景已勾选、且当前消息里确实存在的值，不会为补字段去查询平台接口。详见 [上下文增强说明](docs/上下文增强.md)。

### 访问策略

聊天窗口能碰到 Host 的 Shell、文件与会话，所以默认值按「只有扫码者能用」来定：

- **私聊**：默认「仅白名单用户」——只有扫码绑定的所有者能用；要开放给所有人，必须在设置页显式改成「允许所有用户」。
- **群聊**（QQ）：默认同样只允许白名单；把机器人拉进群不会自动给群成员任何权限。
- **命令权限**：默认只有白名单用户可执行命令；「开放 + 允许命令」等于把 Host 交给该聊天里的所有人，需要显式开启。
- 微信与 QQ 的默认值一致；老版本迁移过来的 QQ 机器人如果只有 `*` 通配所有者，保持原来的可达性但**默认不允许执行命令**。

### 安全边界

以下几件事被刻意限制，避免一条聊天消息就拿到 Host：

- `/permission`：查看档位任何人都可以（只要有命令权限），**切换档位仅限所有者私聊**；`danger-full-access`（完全文件访问、免审批）在 IM 侧一律拒绝，只能在 Web 设置里切换。
- `/workspace`：**仅所有者可用**，且只能切到 DSH 已注册的工作区（或插件自己的默认目录）；`/`、`/etc` 等系统目录与 `..` 一律拒绝。
- `/sessionlist --all` 与 `/session <ID>`：跨工作区枚举和绑定已有会话**仅所有者可用**，避免把别人的会话历史接进群里。
- `dsh_im_return_file`：只发送**当前会话工作区内**的文件；`~/.ssh`、`~/.dsh`、`id_rsa`、`.env`、`*.pem` 等凭据类路径直接拒绝。
- `dsh_im_send`：每次发送都要经过 Host 审批（`allowed-once` 才发），并且每个会话**每分钟最多 3 条**；没有审批应答方时默认拒绝。
  定时任务等无人值守会话可以在 **通用设置 → 投递** 打开「允许无人值守会话直接推送」（或插件配置 `allowUnattendedSend: true`），
  打开后这类会话无需审批即可推送，但**用户明确拒绝的审批永远不会发送**，每分钟 3 条的限制也照旧。

### 排队与插话

在机器人卡片的 **更多设置 → 通用** 中选择「任务运行时的新消息处理方式」：

- **排队（默认）**：当前任务结束后再处理新消息，需要等待时回复排队提示；
- **插话**：任务运行期间，新的纯文字消息作为补充指令加入当前任务，Agent 在下一步读取。

没有运行中的任务时正常开始新任务；图片、文件和带引用的消息仍按原有方式处理。两种模式都可以用 `/steer 补充内容` 手动插话。

### 主动推送

主动推送让外部应用在没有用户新消息时，通过已接入的机器人发送文字：调用方只需保存稳定的 `botId + targetId`，不必保存 `sessionId`、聊天引用或临时 Webhook。设置页支持从已聊会话选择目标、保存前测试路由、复制调用参数，并提供 HTTP POST、同 Host 插件 `ctx.dshIm.send()` 与 Connection RPC 三种调用方式。

助手也可以直接调用 `dsh_im_targets`（列出已配置目标）与 `dsh_im_send`（向 `botId + targetId` 推送文字）主动发消息，不需要外部脚本。出于安全考虑，`dsh_im_send` 每次发送都需要 Host 审批，每个会话每分钟最多 3 条；没有审批应答方的会话会拒绝发送，请改用上面的 HTTP / RPC 投递接口。

微信有一条平台限制：iLink 只在会话有效期内接受发送，过期后返回 `errcode -14`。这类消息不会丢，会进入账号状态里的持久化队列，等对方下次给机器人发消息时按顺序自动送达；调用方会收到 `queued: true` 而不是 `sent: true`。

完整字段、示例、管理端点、错误码与排错说明见 [主动投递使用指南](PROACTIVE_DELIVERY.md)（[English](PROACTIVE_DELIVERY.en.md)）。

### 会话同步

保存私聊投递目标后，可以打开默认关闭的「会话双向同步」：DSH Web 或 CLI 在该私聊当前 Session 中发送的用户文字与最终回答会同步回私聊，定时任务成功完成后也会补发最终回答。开关自动跟随 `/session`、`/new` 与工作区切换后的当前 Session；IM 侧原有的提问与 `/steer` 不会重复发送。首版只同步当前 Host 的私聊文字，不同步图片、文件、卡片与工具过程。

### 模型与思考强度

每张机器人卡片都可以选择 Host 当前可用的模型和该模型支持的思考强度，或跟随 Host 默认。设置按机器人独立保存，只影响之后新建的会话：当前聊天先发 `/new`，再发普通消息才会用上新选择。聊天里也可以用 `/models`、`/model`、`/reasoning` 系列命令查看和切换当前会话的模型。

### 会话标题前缀

Host 的 IM 会话会自动标记来源：Web 会话列表和搜索结果显示「微信 ·」「QQ ·」前缀，并把前缀渲染成渠道 Logo，原始标题和自动标题规则保持不变。图标加载失败或页面结构不匹配时自动退回文字前缀。

### 侧边栏入口

支持全局面板的 DSH 会在左侧边栏提供「IM机器人」，点击打开完整 IM 管理面板；「设置 → IM机器人」和插件详情页的「打开 IM机器人」入口同时保留。宿主插件也可以通过可选客户端服务 `dshImClient` 嵌入面板，接口与示例见 [客户端接入文档](docs/client-integration.md)。

### 多语言

机器人发出的聊天消息、命令帮助跟随 DSH 的界面语言，支持**简体中文、English、Русский**，中文始终兜底。在 **设置 → 通用 → 语言** 里切换 DSH 语言后，机器人从下一条消息起即切换，无需重启或重连。设置页里也可以为机器人消息单独固定语言（跟随 DSH / 中文 / English / Русский），插件配置里的 `language` 选项优先级最高。

### 机器人命令

在聊天里发送命令即可管理会话，完整列表见 [命令说明](docs/机器人命令.md)。

| 命令 | 作用 |
| --- | --- |
| `/help` | 显示可用命令与用法。 |
| `/menu`、`/m` | QQ：打开按钮与数字菜单（会话、工作区、预设、模型、状态等）。 |
| `/new [标题]` | 解除当前聊天的会话绑定，下一条消息开启全新会话。 |
| `/sessionlist`、`/sessions` | 列出会话并标出当前绑定项（`--all` 跨工作区仅所有者可用）。 |
| `/session <ID、序号或标题关键词>` | 把当前聊天绑定到已有会话（仅所有者）。 |
| `/status` | 检查机器人与 Harness 的连接状态。 |
| `/version` | 查看当前运行的插件版本。 |
| `/models`、`/model` | 查看可用模型、当前模型与推理等级，并切换。 |
| `/reasoning`、`/reasoninglist` | 查看并切换当前模型的思考强度。 |
| `/presetlist`、`/preset` | 查看并设置当前机器人的 Agent Preset。 |
| `/workspace`、`/ws` | 查看并切换机器人工作区（仅所有者，且限于已注册工作区）。 |
| `/conv` | 为当前对话设置专属工作区。 |
| `/stop` | 停止当前聊天正在运行的任务。 |
| `/steer <补充指令>` | 把补充指令加入正在运行的任务。 |
| `/compact`、`/clear`、`/reset` | 压缩、清空或重置当前会话上下文。 |
| `/history [数量]` | 在私聊中查看当前会话的最近消息。 |
| `/batch`、`/send`、`/cancel` | 私聊批量输入：最多收集 10 条文字后一次提交。 |

交互式提问直接回复选项序号、选项文字或自定义文字（多选可用逗号分隔）；远程审批回复「批准」「拒绝」「同意」「不同意」「yes」「no」。Web 与机器人可同时处理同一审批，先提交的一方生效，另一端随即失效。

### 图片与文件

- **图片输入**：JPEG、PNG、WebP 以及以图片文件方式发送的 GIF 都可以连同文字说明发给 Harness。默认每张原图最多 30 MB、每条消息最多 20 张；原图保存到会话工作区，模型副本自动缩放到单张 5 MB、总计 20 MB 以内。超限或模型不支持图片时按文件交给模型处理。这四项限制可在 **通用设置 → 附件 → 图片输入** 调整。
- **文件输入**：聊天里发来的文件会保存到会话工作区并交给 Harness 读取。
- **结果回传**：Harness 可读取的文件可以作为渠道原生附件发回聊天；图片优先以原生图片消息呈现，渠道拒绝时回退为文件附件。实际可发送范围以平台接口和配额为准。

### 多机器人与连接管理

同一通道可以接入多个机器人，凭据、连接状态、工作区、模型、Agent Preset 和会话映射各自独立。机器人在线时可以点 **检查连接** 向它最近记录的私聊发送一条测试消息（不创建 Session、不调用模型）；离线时操作变为 **重试连接**；不再使用时 **移除接入** 只影响所选机器人。

## 工作原理

一次对话大致经过这几步：

1. **接入**：设置页向平台申请二维码，扫码确认后凭据写入本机 Host 的凭据存储，插件启动长连接并保持重连。
2. **入站**：平台推送消息 → 通道桥接解析文本、引用、图片和文件 → 按私聊／群聊策略判断是否需要响应 → 交给共享的 `TextHarnessBridge`。
3. **执行**：桥接把消息提交给绑定的 Harness Session（没有绑定就按工作区、Agent Preset 和模型设置新建一个），并把审批、提问、工具进度转成平台能呈现的形态。
4. **出站**：回答按平台能力分段或转 Markdown 发回原聊天；超时未完成的任务由延迟交付机制继续跟踪，完成后补发最终文字。

两个通道共用 `src/channels/shared/` 里的会话绑定、命令、上下文增强、群记录、投递和审批逻辑，只在平台 API、凭据和呈现细节上分叉。这也是为什么两个通道的行为、命令和设置项基本一致。

## 数据与隐私

| 内容 | 默认位置 |
| --- | --- |
| 微信账号配置（含 `bot_token` 引用）、账号状态、工作区 | `~/.dsh/integrations/dsh-weixin/`（`config.json`、`accounts/`、`workspaces.json`） |
| QQ 机器人配置、机器人状态、工作区 | `~/.dsh/integrations/dsh-qq/`（`config.json`、`bots/`、`workspaces.json`） |
| 共享设置：投递同步、侧边栏、界面语言、附件保留 | `~/.dsh/integrations/dsh-im/`（`delivery-sync-settings.json`、`sidebar-settings.json`、`interface-language.json`、`settings.json`） |

设置过 `DSH_HOME` 时，上表中的 `~/.dsh` 由 `DSH_HOME` 代替；插件配置里的 `dshHome` 优先级最高。

### 依赖与供应链

- QQ 扫码依赖 `@tencent-connect/qqbot-connector`：发布物是压缩混淆的 `dist`、`license` 为 `UNLICENSED`、没有
  `repository` 字段，因此升级等同于一坨无法审阅的代码变更。本仓库把它**固定到精确版本**（`1.2.0`），锁文件里保留
  `sha512` integrity，并有测试（`test/dependency-pins.test.mjs`）保证不会被 `^` 范围悄悄升级；要升级请同时更新该测试。
- `@tencent-connect/qqbot-nodejs`（MIT，有官方仓库）与 `qrcode`、`undici` 同样精确固定。
- 微信 iLink 协议由本插件独立实现，**不是腾讯背书的客户端**；请求里声明的客户端标识是
  `DeepSeekHarness/dsh-im-<版本>`，可以通过插件配置 `botAgent` 覆盖。平台若调整协议或限制该标识，插件可能需要跟进。

隐私与安全边界：

- 扫码得到的 Token、Secret 只提交给本机 Harness Host，写入受保护的凭据存储；浏览器只会拿到二维码、脱敏状态和机器人列表，任何 RPC 响应都不会返回原始凭据。
- 机器人状态文件只保存会话绑定、`senderId` 与「是否机器人」等身份信息；微信账号状态另存 `context_token` 与最近 200 条出站正文用于补发，文件权限 0600。
- 群聊记录只保存实际收到的消息与附件，按群共享、按保留天数滚动清理。
- 管理接口与投递 HTTP 接口沿用 DSH 的浏览器登录态校验（未登录请求返回 401），只应在本机或可信网络使用，不要暴露到公网。

## 常见问题

### 扫码后没有反应，或二维码已过期

二维码由平台服务签发并有有效期。点 **重新生成二维码** 换一张，再确认手机端网络正常、扫码后确实在手机上点了确认。微信在平台要求时会提示「需要配对码」，此时必须在设置页输入手机上显示的数字；只扫码不输入配对码不会完成绑定。多次失败可以展开页面里的 **诊断详情**，复制诊断信息后排查，其中会包含 `WX-CONN-…` 或 `IM-CONN-…` 参考号。

### 提示凭据失效或机器人掉线

先确认该账号没有在其他地方被解绑、改密或退出登录。凭据失效时，移除该账号后重新扫码绑定即可；其他账号不受影响。插件会按退避策略自动重连，页面上的 **重试连接** 可以立即再试一次。

### 机器人显示离线，但网络正常

- 检查 Host 是否刚重启过，重启后需要几秒恢复长连接。
- 微信：iLink 长轮询在线不代表主动发送一定可用；如果持续出现 `ret=-2 prepare failed`，让目标用户先发一条消息再重试，不要靠反复发送心跳续期。
- QQ：确认机器人在腾讯侧仍处于启用状态，并检查本机能否访问 QQ 开放平台。
- 仍不通时展开 **诊断详情**，把参考号连同 Host 日志一起用于排查。

### 端口、局域网与反向代理

- IM 管理接口默认沿用 Harness 的浏览器认证与 Host／Origin 信任检查；DSH 已允许局域网访问时，可以直接在局域网或 NAS 上配置机器人，无需额外修改插件配置。
- 通过自定义域名访问时，如果设置页报 `transport failure for /api/dsh-im/...: HTTP 403`，请在启动 DSH 时加上实际域名并重启：`dsh web --trusted-host dsh.example.com`。只写域名即可，多个域名重复传参。
- 想把管理接口限制为仅本机访问，可在 profile 的 `cordis.patch.yml` 里设置 `rpcAuthority: loopback`（默认为 `trusted-host`）。
- 反向代理需要保留浏览器访问的域名与端口，并保证 `Origin` 与 `Host` 一致，否则仍会返回 403。

### 机器人为什么不回复群消息

QQ 群聊只在被 @ 时响应；群聊白名单、命令权限和「任务运行时的新消息处理方式」也会影响是否回复。微信目前只支持私聊。

### 升级后页面没有变化

插件更新后需要重启 Host 并刷新浏览器；只刷新页面时 Host 仍运行旧代码。可以在 **设置 → IM机器人** 右上角的「检查更新」里确认版本，更新只涉及 `@xdlg93/dsh-im`，不会改动 Harness 或 Desktop 本体。

### 如何备份或迁移已绑定的账号

配置与状态都在上表的数据目录里，按目录整体复制即可迁移。凭据存储由 Harness 管理，只复制配置文件不会带上 Token；换机器后建议移除旧账号、重新扫码绑定，避免旧凭据继续占用平台的机器人名额。

### 能改机器人的显示名称吗

可以。点击卡片上机器人名称旁的铅笔即可设置别名，保存后立即生效，无需重启或重连。别名只影响本机设置页的显示，随时可以恢复原名称。别名不影响 `botId`，主动投递的调用参数不需要改。

### 一个机器人可以同时服务多个聊天吗

可以。每个聊天（私聊或群）各自绑定自己的 Harness 会话，互不干扰；同一个聊天也可以用 `/session` 切换绑定的会话。群聊记录按群共享，独立于机器人和会话。

## 开发

```sh
npm install
npm run build   # 构建 lib/index.js 与 lib/client.js
npm test        # 单元测试
npm run check   # 构建 + 测试 + 发布包校验
```

源码结构：

- `src/channels/weixin/`、`src/channels/qq/`：两个通道的配置、状态、API、桥接与运行时；
- `src/channels/shared/`：会话、命令、上下文增强、群记录、投递等共享能力；
- `plugin-src/host/`：Host 侧 RPC、连接监督、生产装配；
- `plugin-src/client/`：设置页与侧边栏面板；
- `lib/index.js`、`lib/client.js`：构建产物，也是 `package.json` 的入口。

修改客户端代码后需要重新构建；插件由 `cordis.patch.yml` 以 `xdlg93-dsh-im` 注册。

## 许可证与致谢

- 本项目以 **MIT** 许可发布，全文见 [LICENSE](LICENSE)。
- 上游项目：[xmanrui/dsh-im](https://github.com/xmanrui/dsh-im)（MIT），本仓库的微信、QQ 通道实现与大部分共享能力来自上游 5.10.0。
- 微信 iLink 请求格式与扫码状态机参考腾讯 [`openclaw-weixin`](https://github.com/Tencent/openclaw-weixin)（MIT）。
- QQ 扫码绑定与消息收发依赖腾讯 Connect 的 [`@tencent-connect/qqbot-connector`](https://www.npmjs.com/package/@tencent-connect/qqbot-connector) 与 [`@tencent-connect/qqbot-nodejs`](https://github.com/tencent-connect/qqbot)。
- 其他第三方组件、许可文本与商标说明见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。

本项目是独立的 DeepSeek Harness 集成，与腾讯、DeepSeek 官方无隶属关系；微信、QQ 等名称与标识归各自权利人所有。
